"""Offline test of the installed plugin over the MCP SDK client."""
import argparse
import asyncio
import hashlib
import json
from pathlib import Path
import sys
from uuid import uuid4

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

REQUIRED = {'client_status','nk_card','suz_order_status','suz_orders','gis_documents',
            'gis_document','gis_code_status','gis_check_completion','prepare_remark_draft',
            'label_demo','build_client_labels'}


async def smoke(plugin, state):
    sys.path.insert(0,str(plugin/'server'))
    from demo import GTIN,ORDER,DOCUMENT,CIS,INN
    from clients import Journal,Transport,TRUE,SUZ,NK
    from workflow import accepted_document_id,completion
    from gs1 import source_page
    from labels import build_pdf,build_from_codes
    import pymupdf as fitz

    sandbox_profile = state / 'profile.json'
    assert json.loads(sandbox_profile.read_text())['mode']=='demo'
    assert not (state/'secrets').exists()
    command=StdioServerParameters(command=sys.executable,args=[str(plugin/'server/launch.py')],
                                  cwd=str(plugin),env={'MARKING_CLIENT_HOME':str(state)})
    checks = {}
    async with stdio_client(command) as (reader,writer):
        async with ClientSession(reader,writer) as session:
            await session.initialize()
            available = {t.name for t in (await session.list_tools()).tools}
            assert available==REQUIRED,available
            checks['mcp_discovery']=sorted(available)

            async def call(name, args=None, failure=False):
                response = await session.call_tool(name,args or {})
                assert bool(response.isError)==failure,(name,response)
                if failure:
                    return None
                result=response.structuredContent or json.loads(response.content[0].text)
                return result

            status=await call('client_status')
            assert status['mode']=='demo' and not status['live_write_tools']
            assert all(x['live_connection']=='UNKNOWN' and not x['configured'] for x in status['credentials'].values())
            checks['credential_isolation']='PASS'
            assert (await call('nk_card',{'gtin':GTIN}))['result']['package_type']=='UNIT'
            assert (await call('nk_card',{'gtin':'00000000000018'},failure=True)) is None
            checks['nk_exact_gtin']='PASS'
            status=await call('suz_order_status',{'order_id':ORDER,'gtin':GTIN})
            assert status['result'][0]['leftInBuffer']==0
            orders=await call('suz_orders',{'product_group':'lp','start_ms':1735689600000,'end_ms':1767225600000})
            assert orders['result']['complete'] and orders['result']['results'][0]['orderId']==ORDER
            checks['suz_list_and_status']='PASS'
            args={'product_group':'lp','direction':'outgoing','date_from':'2025-01-01T00:00:00Z',
                  'date_to':'2025-12-31T23:59:59Z'}
            data=(await call('gis_documents',args))['result']
            assert data['complete'] and data['pages']==2 and len(data['results'])==2
            assert not (await call('gis_documents',{**args,'max_pages':1}))['result']['complete']
            assert (await call('gis_documents',{**args,'direction':'incoming'}))['result']['results']==[]
            checks['gis_pagination_and_direction']='PASS'
            ref={'product_group':'lp','document_id':DOCUMENT}
            letter=(await call('gis_document',ref))['result']
            assert letter['status']=='CHECKED_OK'
            found=(await call('gis_code_status',{'product_group':'lp','identification_codes':[CIS]}))['result']
            assert found[0]['cisInfo']['status']=='INTRODUCED'
            assert (await call('gis_check_completion',{**ref,'identification_codes':[CIS]}))['result']['complete']
            assert not completion(letter,DOCUMENT,[CIS],[{'cisInfo':{'cis':CIS,'status':'APPLIED','ownerInn':INN}}],[CIS],INN)['complete']
            assert not completion(letter,DOCUMENT,[CIS],found+found,[CIS],INN)['complete']
            assert not completion(letter,DOCUMENT,[],found,[CIS],INN)['complete']
            checks['exact_final_status_and_coverage']='PASS'
            draft={'operation_date':'2025-01-02','reason':'KM_SPOILED','applied_confirmed':False,
                   'products':[{'new_uin':CIS,'package_type':'UNIT','tnved_10':'0000000000'}]}
            await call('prepare_remark_draft',draft,failure=True)
            assert (await call('prepare_remark_draft',{**draft,'applied_confirmed':True}))['result']['state']=='UNSIGNED_DRAFT'
            checks['physical_application_gate_and_draft']='PASS'
            name='verified-demo-'+uuid4().hex[:8]
            report=await call('label_demo',{'output_name':name})
            assert report['result']['status']=='PASS' and report['result']['dpi']==[203,300]
            path=Path(report['local_file'])
            assert hashlib.sha256(path.read_bytes()).hexdigest()==report['result']['sha256']
            with fitz.open(path) as pdf:
                assert len(pdf)==1 and 'DEMO / NOT FOR SALE' in pdf[0].get_text()
            await call('label_demo',{'output_name':name},failure=True)
            await call('label_demo',{'output_name':'../unsafe'},failure=True)
            checks['demo_pdf']=report['result']
            checks['demo_pdf_path']=str(path)

    # Exercise the original payload adapter with synthetic AI 91/92 fields.
    # This symbol is never used on a product.
    raw=CIS+'\x1d91TEST\x1d92DEMO-NO-CRYPTO'
    template=json.loads((plugin/'templates/label.example.json').read_text())
    item={'title':'DEMO API PAYLOAD','sku':'DEMO-02','gtin':GTIN,'linear_format':'CODE128','linear_code':'DEMO-02'}
    path=state/'workspace'/('demo-api-'+uuid4().hex[:8]+'.pdf')
    api_report=build_from_codes([raw],item,template,path,1)
    assert api_report['count']==1
    checks['source_api_bytes_and_code128']='PASS'

    for verb,base,route in [('GET',SUZ,'/api/v3/codes'),('GET',NK,'/v3/feed-moderation'),
                            ('POST',TRUE,'/lk/documents/create'),('POST',SUZ,'/api/v3/order')]:
        try:
            Transport().call(verb,base,route)
        except PermissionError:
            continue
        raise AssertionError('Write request was not rejected by the transport')
    journal=Journal(state/'workflow-journal')
    journal_id='demo-'+uuid4().hex
    journal.begin(journal_id,{'demo':True})
    try:
        journal.begin(journal_id,{'demo':True})
    except FileExistsError:
        pass
    else:
        raise AssertionError('Repeated intent was allowed')
    assert accepted_document_id(201,DOCUMENT.encode())==DOCUMENT
    checks['read_only_routes_and_duplicate_intent']='PASS'
    return checks


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('plugin',type=Path)
    parser.add_argument('state',type=Path)
    args=parser.parse_args()
    result=asyncio.run(smoke(args.plugin.resolve(),args.state.resolve()))
    print(json.dumps(result,indent=2,ensure_ascii=False))
