"""Provision a dedicated Python environment and empty example profile."""
from pathlib import Path
import os
import subprocess
import sys
import venv

root = Path(os.environ.get('MARKING_CLIENT_HOME', Path.home() / '.local/share/marking-operations-client')).expanduser()
plugin = Path(__file__).resolve().parent

if __name__=='__main__':
    if sys.version_info[:2] not in {(3,12),(3,13)}:
        raise SystemExit('Use local Python 3.12 or 3.13.')
    root.mkdir(mode=0o700,parents=True,exist_ok=True)
    environment=root/'venv'
    venv.EnvBuilder(with_pip=True).create(environment)
    dependencies=environment/('Scripts/python.exe' if os.name=='nt' else 'bin/python')
    subprocess.run([str(dependencies),'-m','pip','--disable-pip-version-check','install','--only-binary=:all:',
                    '-r',str(plugin/'requirements.txt')],check=True)
    subprocess.run([str(dependencies),'-m','pip','check'],check=True)
    for source,destination in [('profile.example.json','profile.json'),('catalog.example.csv','catalog.csv'),
                               ('label.example.json','label.example.json')]:
        tgt=root/destination
        if not tgt.exists():
            with tgt.open('xb') as stream:
                stream.write((plugin/'templates'/source).read_bytes())
    (root/'workspace').mkdir(mode=0o700,exist_ok=True)
    print('Готово. Режим demo доступен при отсутствии ранее настроенного профиля.')
