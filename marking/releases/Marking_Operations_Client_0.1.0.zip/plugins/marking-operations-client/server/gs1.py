"""Adapted GS1 ECC200 Zint 2.16 ABI prefix and byte-for-byte round trip."""
import ctypes as C
from ctypes.util import find_library
from pathlib import Path
import tempfile

import pymupdf as fitz
import zxingcpp as zx

class Symbol(C.Structure):
 _fields_=[('symbology',C.c_int),('height',C.c_float),('scale',C.c_float),('whitespace_width',C.c_int),('whitespace_height',C.c_int),('border_width',C.c_int),('output_options',C.c_int),('fgcolour',C.c_char*16),('bgcolour',C.c_char*16),('fgcolor',C.c_void_p),('bgcolor',C.c_void_p),('outfile',C.c_char*256),('primary',C.c_char*128),('option_1',C.c_int),('option_2',C.c_int),('option_3',C.c_int),('show_hrt',C.c_int),('input_mode',C.c_int),('eci',C.c_int)]


def scan(page, dpi):
    from PIL import Image
    px = page.get_pixmap(dpi=dpi, alpha=False)
    return zx.read_barcodes(Image.frombytes('RGB', (px.width, px.height), px.samples))


def zint():
    candidates = [find_library('zint'), *Path(zx.__file__).parent.glob('*zxing*.so'),
                  *Path(zx.__file__).parent.glob('*zxing*.pyd')]
    for candidate in filter(None,candidates):
        try:
            lib = C.CDLL(str(candidate))
            lib.ZBarcode_Version.restype = C.c_int
            if lib.ZBarcode_Version() != 21600:
                continue
            lib.ZBarcode_Create.restype = C.POINTER(Symbol)
            lib.ZBarcode_Delete.argtypes = [C.POINTER(Symbol)]
            lib.ZBarcode_Encode_and_Print.argtypes = [C.POINTER(Symbol), C.c_char_p, C.c_int, C.c_int]
            lib.ZBarcode_Encode_and_Print.restype = C.c_int
            return lib
        except (OSError, AttributeError):
            continue
    raise RuntimeError('Zint 2.16.0 ABI unavailable; use original PDFs or install the compatible library')


def source_page(raw, demo=False):
    """Only the verified apparel field layout is accepted for an original API string."""
    if b'[' in raw or b']' in raw:
        raise ValueError('Unsupported AI notation characters')
    parts = raw.split(b'\x1d')
    head = parts[0]
    if len(head) != 31 or head[:2] != b'01' or head[16:18] != b'21':
        raise ValueError('Unsupported code layout')
    content = b'[01]' + head[2:16] + b'[21]' + head[18:]
    if demo:
        from demo import CIS
        if raw != CIS.encode('ascii'):
            raise ValueError('Synthetic encoder accepts only its known fixture')
    else:
        if len(parts) != 3 or len(parts[1]) != 6 or parts[1][:2] != b'91' or not parts[2].startswith(b'92') or len(parts[2]) <= 2:
            raise ValueError('Unsupported code layout: expected AI 91 and 92')
        content += b'[91]' + parts[1][2:] + b'[92]' + parts[2][2:]
    lib = zint()
    with tempfile.TemporaryDirectory(prefix='marking-gs1-') as folder:
        path = Path(folder) / 'symbol.svg'
        ptr = lib.ZBarcode_Create()
        if not ptr:
            raise RuntimeError('Cannot allocate Data Matrix encoder')
        try:
            symbol = ptr.contents
            symbol.symbology = 71
            symbol.input_mode = 2
            symbol.eci = 0
            symbol.whitespace_width = 2
            symbol.whitespace_height = 2
            symbol.outfile = str(path).encode()
            if lib.ZBarcode_Encode_and_Print(ptr, content, len(content), 0):
                raise ValueError('Zint rejected the GS1 payload')
        finally:
            lib.ZBarcode_Delete(ptr)
        with fitz.open(stream=path.read_bytes(), filetype='svg') as svg:
            data = svg.convert_to_pdf()
    with fitz.open(stream=data, filetype='pdf') as source:
        codes = scan(source[0],300)
        if len(codes) != 1 or codes[0].symbology_identifier != ']d2' or bytes(codes[0].bytes) != raw:
            raise ValueError('GS1 round trip failed')
    return data
