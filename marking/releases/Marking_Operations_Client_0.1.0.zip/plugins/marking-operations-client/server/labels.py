"""Client-configurable PDF layout. Original Data Matrix symbols are copied from source pages."""
from collections import Counter
import hashlib
from io import BytesIO
import json
import math
import os
from pathlib import Path

import pymupdf as fitz
import zxingcpp as zx
from reportlab.graphics.barcode import createBarcodeDrawing
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfgen.canvas import Canvas

from clients import validate_codes, valid_gtin, secure_write
from gs1 import scan, source_page

MM = 72 / 25.4


def rect_mm(values, size):
    x,y,w,h = values
    if not all(math.isfinite(v) for v in values) or min(x,y)<0 or min(w,h)<=0 or x+w>size[0] or y+h>size[1]:
        raise ValueError('A layout box falls outside the page')
    return fitz.Rect(x*MM,y*MM,(x+w)*MM,(y+h)*MM)


def pick_dm(page):
    return [code for code in scan(page,300) if code.format == zx.BarcodeFormat.DataMatrix]


def source_rect(code, page):
    points = [code.position.top_left,code.position.top_right,code.position.bottom_left,code.position.bottom_right]
    box = fitz.Rect(min(p.x for p in points),min(p.y for p in points),
                    max(p.x for p in points),max(p.y for p in points)) * (72/300)
    if min(box.width,box.height) <= 0:
        raise ValueError('Cannot locate original symbol')
    quiet = min(box.width,box.height) * .1
    return (box + (-quiet,-quiet,quiet,quiet)) & page.rect


def template_page(item, template, font_file, demo):
    size = template['page_mm']
    if len(size)!=2 or not all(math.isfinite(v) and 20<=v<=300 for v in size):
        raise ValueError('Invalid page geometry')
    dm_rect = rect_mm(template['dm_mm'],size)
    bar_rect = rect_mm(template['linear_mm'],size)
    if dm_rect.intersects(bar_rect):
        raise ValueError('Barcode boxes overlap')
    linear = item['linear_code']
    form = item['linear_format']
    if form=='EAN13' and (len(linear)!=13 or not valid_gtin(linear)):
        raise ValueError('Invalid EAN-13')
    if form=='CODE128' and (not linear or not linear.isascii() or not linear.isprintable() or len(linear)>40):
        raise ValueError('Invalid Code 128 content')
    if form not in ('EAN13','CODE128'):
        raise ValueError('Unsupported linear format')
    font = 'Helvetica'
    if font_file:
        font = 'ClientFont'
        pdfmetrics.registerFont(TTFont(font,str(font_file)))
    stream = BytesIO()
    canvas = Canvas(stream,pagesize=tuple(v*MM for v in size),pageCompression=1)
    texts = []
    regions = [dm_rect,bar_rect]
    for field in template['text']:
        x,y = field['at_mm']
        max_mm, pt = field['max_mm'],field['size_pt']
        value = item[field['field']]
        if not isinstance(value,str) or not value or not value.isprintable() or (not font_file and not value.isascii()):
            raise ValueError('Provide a compatible client font and printable label text')
        if not 4<=pt<=24 or pdfmetrics.stringWidth(value,font,pt)>max_mm*MM:
            raise ValueError('Text does not fit the approved template')
        width = pdfmetrics.stringWidth(value,font,pt) / MM
        region = rect_mm([x,y,width,pt*1.3/MM],size)
        if any(region.intersects(region2) for region2 in regions):
            raise ValueError('Text overlaps a reserved region')
        regions.append(region)
        canvas.setFont(font,pt)
        canvas.drawString(x*MM,size[1]*MM-y*MM-pt,value)
        texts.append(value)
    if demo:
        canvas.setFont('Helvetica-Bold',9)
        canvas.drawString(29*MM,size[1]*MM-15*MM,'DEMO / NOT FOR SALE')
        texts.append('DEMO / NOT FOR SALE')
    options = {'barWidth':.54,'lquiet':5.4,'rquiet':5.4} if form=='CODE128' else {}
    drawing = createBarcodeDrawing('EAN13' if form=='EAN13' else 'Code128',value=linear,
                                   barHeight=35,humanReadable=True,quiet=True,**options)
    drawing.scale(bar_rect.width/drawing.width,bar_rect.height/drawing.height)
    drawing.drawOn(canvas,bar_rect.x0,size[1]*MM-bar_rect.y1)
    canvas.showPage()
    canvas.save()
    return stream.getvalue(), tuple(v*MM for v in size), dm_rect, texts


def verify_pdf(data, expected_raw, item, size, texts):
    expected = set(expected_raw)
    seen = set()
    fmt = zx.BarcodeFormat.EAN13 if item['linear_format']=='EAN13' else zx.BarcodeFormat.Code128
    with fitz.open(stream=data,filetype='pdf') as pdf:
        if len(pdf)!=len(expected):
            raise ValueError('PDF page count mismatch')
        for page in pdf:
            if page.rotation or abs(page.rect.width-size[0])>.05 or abs(page.rect.height-size[1])>.05:
                raise ValueError('PDF geometry mismatch')
            visible = ' '.join(page.get_text().split())
            if not all(' '.join(field.split()) in visible for field in texts):
                raise ValueError('PDF is missing a required text field')
            for dpi in (203,300):
                codes = scan(page,dpi)
                dm = [c for c in codes if c.format==zx.BarcodeFormat.DataMatrix]
                linear = [c for c in codes if c.format==fmt]
                if len(dm)!=1 or len(codes)!=2 or dm[0].symbology_identifier!=']d2' or len(linear)!=1 or linear[0].text!=item['linear_code']:
                    raise ValueError(f'Barcode readability / content failed at {dpi} DPI')
                raw=bytes(dm[0].bytes)
                if raw not in expected or (dpi==300 and raw in seen):
                    raise ValueError('Original Data Matrix mismatch or duplicate')
                if dpi==300:
                    seen.add(raw)
    if seen != expected:
        raise ValueError('PDF does not cover the original codes')
    return {'status':'PASS','count':len(seen),'gtin14':item['gtin'],'dpi':[203,300],
            'page_mm':[round(v/MM,4) for v in size],'sha256':hashlib.sha256(data).hexdigest(),
            'scope':'digital_pdf_checks'}


def build_pdf(source, item, template, output, quantity, font_file=None, demo=False):
    if type(quantity) is not int or not 1<=quantity<=2000:
        raise ValueError('Supply the expected quantity (1–2000)')
    background,size,dm_rect,texts=template_page(item,template,font_file,demo)
    prefix = ('01'+item['gtin']+'21').encode('ascii')
    expected=[]
    codes_seen=set()
    with fitz.open(stream=background,filetype='pdf') as layout, fitz.open() as result:
        for page in source:
            symbols=pick_dm(page)
            if not symbols:
                raise ValueError('Source PDF page has no Data Matrix')
            for symbol in symbols:
                raw=bytes(symbol.bytes)
                cis=raw.split(b'\x1d',1)[0]
                if not raw.startswith(prefix) or len(cis)<=len(prefix) or cis in codes_seen or symbol.symbology_identifier!=']d2':
                    raise ValueError('Invalid GTIN/GS1 or duplicate source code')
                codes_seen.add(cis)
                expected.append(raw)
                target=result.new_page(width=size[0],height=size[1])
                target.show_pdf_page(target.rect,layout,0)
                target.show_pdf_page(dm_rect,source,page.number,clip=source_rect(symbol,page))
        if len(expected)!=quantity:
            raise ValueError('Source count differs from expected quantity')
        pdf=result.tobytes(garbage=4,deflate=True)
    report=verify_pdf(pdf,expected,item,size,texts)
    secure_write(output,pdf)
    return report


def build_from_codes(codes, item, template, output, quantity, font_file=None):
    validate_codes(codes,{item['gtin']:quantity})
    with fitz.open() as source:
        for code in codes:
            with fitz.open(stream=source_page(code.encode('ascii')),filetype='pdf') as one:
                source.insert_pdf(one)
        return build_pdf(source,item,template,output,quantity,font_file)
