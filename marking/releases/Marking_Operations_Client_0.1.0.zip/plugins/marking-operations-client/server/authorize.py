"""Operator-only authorization setup. Invoked directly by the client in a local terminal."""
import argparse
import base64
from getpass import getpass
import os
from pathlib import Path
import re
import subprocess
import sys
import tempfile
from uuid import UUID

from clients import Transport,TRUE,secure_write
from client_profile import Profile,SECRET_NAMES


def login(profile, service):
    if profile.mode!='live_readonly':
        raise ValueError('Configure live_readonly and the client participant first')
    thumb=profile.data.get('certificate_thumbprint','')
    executable=Path(profile.data.get('cryptcp_command',''))
    if not re.fullmatch('[a-fA-F0-9]{40}',thumb) or not executable.is_absolute() or not executable.is_file():
        raise ValueError('Configure the local CryptoPro executable and client thumbprint')
    connection = '/' + str(UUID(profile.data['oms_connection'])) if service=='suz' else ''
    transport=Transport(allow_auth=True)
    challenge=transport.call('GET',TRUE,'/auth/key')
    with tempfile.TemporaryDirectory(prefix='marking-auth-') as tmp:
        inp, out = Path(tmp)/'challenge',Path(tmp)/'signed'
        secure_write(inp,challenge['data'].encode('utf-8'))
        signed=subprocess.run([str(executable),'-sign','-thumbprint',thumb,'-attached',
                              '-der','-strict',str(inp),str(out)], stdout=subprocess.DEVNULL,
                              stderr=subprocess.DEVNULL,check=False,timeout=90)
        if signed.returncode!=0:
            raise ValueError('CryptoPro authorization signature failed')
        body={'uuid':challenge['uuid'],'data':base64.b64encode(out.read_bytes()).decode('ascii')}
        if service=='gis':
            body['unitedToken']=True
        result=transport.call('POST',TRUE,'/auth/simpleSignIn'+connection,body=body)
    token=result.get('token')
    if not isinstance(token,str) or not token or any(c.isspace() for c in token):
        raise ValueError('Authorization response did not return a recognized token')
    return token


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('service',choices=SECRET_NAMES)
    parser.add_argument('--cryptopro-login',action='store_true')
    args=parser.parse_args()
    if not sys.stdin.isatty() or args.cryptopro_login and args.service=='nk':
        parser.error('Use an interactive local terminal; CryptoPro login is only for SUZ/GIS MT')
    profile=Profile()
    folder=profile.root/'secrets'
    folder.mkdir(mode=0o700,parents=True,exist_ok=True)
    if folder.is_symlink() or (os.name=='posix' and (folder.stat().st_uid!=os.getuid() or folder.stat().st_mode & 0o077)):
        parser.error('Secrets directory must belong to the current user with mode 700')
    value=login(profile,args.service) if args.cryptopro_login else getpass('Вставьте ключ или токен в скрытый запрос: ').strip()
    if not value or any(c.isspace() for c in value):
        parser.error('Invalid credential')
    with tempfile.TemporaryDirectory(dir=folder) as temp:
        staged=Path(temp)/'secret'
        secure_write(staged,value.encode('utf-8'))
        os.replace(staged,folder/SECRET_NAMES[args.service])
    print('Учетные данные сохранены локально. Проверьте доступ отдельным чтением в новом чате.')


if __name__=='__main__':
    try:
        main()
    except Exception as error:
        print('Ошибка локальной авторизации:', type(error).__name__,file=sys.stderr)
        raise SystemExit(1)
