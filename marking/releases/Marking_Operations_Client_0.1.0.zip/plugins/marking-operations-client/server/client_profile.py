import csv
import json
import os
import re
import stat
from pathlib import Path

from clients import valid_gtin

ROOT = Path(__file__).resolve().parents[1]
SECRET_NAMES = {'nk': 'nk.key', 'suz': 'suz.token', 'gis': 'gis.token'}


def state_dir():
    return Path(os.environ.get('MARKING_CLIENT_HOME', Path.home() / '.local/share/marking-operations-client')).expanduser().resolve()


def restricted_file(root, name):
    base = root.resolve()
    path = (base / name).resolve()
    if not path.is_relative_to(base):
        raise ValueError('Path outside the client directory')
    return path


def valid_inn(value):
    if not re.fullmatch(r'[0-9]{10}|[0-9]{12}', value):
        return False
    digits = list(map(int, value))
    if len(digits) == 10:
        return sum(a*b for a,b in zip(digits, [2,4,10,3,5,9,4,6,8])) % 11 % 10 == digits[9]
    a = sum(x*y for x,y in zip(digits, [7,2,4,10,3,5,9,4,6,8])) % 11 % 10
    b = sum(x*y for x,y in zip(digits, [3,7,2,4,10,3,5,9,4,6,8])) % 11 % 10
    return (a,b) == (digits[10],digits[11])


class Profile:
    def __init__(self, root=None):
        self.root = root or state_dir()
        path = self.root / 'profile.json'
        self.data = json.loads(path.read_text(encoding='utf-8')) if path.is_file() else {'mode':'demo'}
        self.mode = self.data['mode']
        if self.mode not in ('demo', 'live_readonly'):
            raise ValueError('Unknown profile mode')
        self.inn = self.data.get('participant_inn', '')
        self.groups = self.data.get('product_groups', [])
        if self.mode == 'live_readonly' and (not valid_inn(self.inn) or not self.groups or
                not all(re.fullmatch(r'[a-z][a-z0-9_-]{0,24}', group) for group in self.groups)):
            raise ValueError('Set the client participant INN and product groups')

    def secret(self, service):
        path = restricted_file(self.root, 'secrets/' + SECRET_NAMES[service])
        if not path.is_file():
            raise ValueError('Credentials absent for the selected service')
        metadata = path.stat()
        if os.name == 'posix' and (stat.S_IMODE(metadata.st_mode) & 0o077 or metadata.st_uid != os.getuid()):
            raise ValueError('Use a credential file owned by the local user with mode 600')
        value = path.read_text(encoding='utf-8').strip()
        if not value or len(value) > 32768 or any(ch.isspace() for ch in value):
            raise ValueError('Invalid credential file format')
        return value

    def product_group(self, group):
        if group not in (['lp', 'grocery'] if self.mode == 'demo' else self.groups):
            raise ValueError('Product group is outside the configured profile')
        return group

    def catalog_item(self, sku):
        path = restricted_file(self.root, self.data.get('catalog_csv', 'catalog.csv'))
        with path.open(encoding='utf-8-sig', newline='') as stream:
            matches = [r for r in csv.DictReader(stream) if r.get('sku') == sku]
        if len(matches) != 1:
            raise ValueError('The SKU must occur exactly once in the master catalogue')
        row = matches[0]
        if not valid_gtin(row['gtin']) or not row['title']:
            raise ValueError('Invalid catalogue item')
        self.product_group(row['product_group'])
        row['gtin'] = row['gtin'].zfill(14)
        return row
