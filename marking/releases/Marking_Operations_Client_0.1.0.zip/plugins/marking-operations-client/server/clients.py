"""Read-only CRPT client adapter. Wire methods derived from the verified local clients."""
from pathlib import Path
import hashlib, json, os, re, time
from curl_cffi import requests

NK='https://xn--80aqu.xn----7sbabas4ajkhfocclk9d3cvfsa.xn--p1ai'
TRUE='https://markirovka.crpt.ru/api/v3/true-api'
SUZ='https://suzgrid.crpt.ru'
def encoded(value): return json.dumps(value,ensure_ascii=False,separators=(',',':')).encode()
def digest(value): return hashlib.sha256(encoded(value)).hexdigest()
def secret(path):
 p=Path(path).expanduser()
 if p.stat().st_mode & 0o077: raise PermissionError('Secret file must have mode 600')
 return p.read_text().strip()
def secure_write(path,data):
 fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
 with os.fdopen(fd,'wb') as f:f.write(data)
class Transport:
 def __init__(self, allow_auth=False):
  self.allow_auth=allow_auth
  self.s=requests.Session(impersonate='chrome',verify=True,timeout=(10,30),trust_env=False,headers={'Accept':'application/json'})
  self.audit=[]
 def call(self,method,base,path,params=None,body=None,headers=None,raw=None):
  read_routes={
   ('GET',NK,'/v3/feed-product'), ('GET',SUZ,'/api/v3/order/status'),
   ('POST',SUZ,'/api/v3/orders/search'), ('POST',TRUE,'/cises/info'),
   ('GET',TRUE,'/doc/cises'), ('GET',TRUE.replace('/v3/','/v4/'),'/doc/list'),
  }
  document_read=(method=='GET' and base==TRUE.replace('/v3/','/v4/') and
                 re.fullmatch(r'/doc/(?!\.{1,2}/)[A-Za-z0-9_.-]{1,300}/info',path))
  auth=(self.allow_auth and base==TRUE and ((method,path)==('GET','/auth/key') or
         method=='POST' and re.fullmatch(r'/auth/simpleSignIn(?:/[0-9a-f-]{36})?', path)))
  if (method,base,path) not in read_routes and not document_read and not auth:
   raise PermissionError('Route is outside the read-only allowlist')
  start=time.monotonic()
  try:r=self.s.request(method,base+path,params=params,json=body,data=raw,headers=headers,allow_redirects=False)
  except Exception as e:
   message='Network request failed'
   for k,v in {**(params or {}),**(headers or {})}.items():
    if k.lower() in ('apikey','authorization','clienttoken','x-signature'):message=message.replace(str(v),'[REDACTED]')
   self.audit.append({'method':method,'path':path,'message':message[:1500],'errno':getattr(e,'errno',None),'error_type':type(e).__name__,'curl_code':getattr(e,'code',None),'seconds':round(time.monotonic()-start,2)})
   raise RuntimeError('Transport failed; no retry; consult audit') from None
  entry={'method':method,'path':path,'http':r.status_code,'content_type':r.headers.get('content-type'),'seconds':round(time.monotonic()-start,2)}
  self.audit.append(entry)
  if r.status_code!=200:raise RuntimeError(f'HTTP {r.status_code}; no retry')
  if 'json' not in r.headers.get('content-type',''):raise RuntimeError('Non-JSON response; no retry')
  return r.json()
def valid_gtin(gtin):
 return isinstance(gtin,str) and len(gtin) in (13,14) and gtin.isascii() and gtin.isdigit() and int(gtin[-1])==(-sum(int(x)*(3 if i%2==0 else 1) for i,x in enumerate(gtin[-2::-1])))%10
class Journal:
 """Exclusive durable intent BEFORE IO. Unknown outcomes never auto-retry."""
 def __init__(self,root):self.root=Path(root);self.root.mkdir(parents=True,exist_ok=True)
 def begin(self,operation_id,payload):
  if not operation_id or any(c not in 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_' for c in operation_id):raise ValueError('Unsafe operation id')
  p=self.root/(operation_id+'.json')
  fd=os.open(p,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
  with os.fdopen(fd,'w') as f:json.dump({'state':'UNKNOWN','hash':digest(payload)},f);f.flush();os.fsync(f.fileno())
  return p
 def confirm(self,p,remote_id,readback_verified):
  if not readback_verified:raise ValueError('Independent readback required')
  state=json.loads(p.read_text());state.update(state='VERIFIED',remote_id=remote_id)
  temp=p.with_suffix('.new');secure_write(temp,encoded(state));os.replace(temp,p)
def card_type(card,gtin):
 rows=[r for r in card.get('result',[]) if any(i.get('value','').zfill(14)==gtin for i in r.get('identified_by',[]))]
 if len(rows)!=1:raise ValueError('Card match is not unique')
 r=rows[0]
 if r.get('good_status')!='published' or not r.get('good_mark_flag'):raise ValueError('Card is not ready for marking')
 if r.get('is_set'):raise ValueError('SET is not supported by this apparel workflow')
 if type(r.get('is_kit')) is not bool:raise ValueError('Card package type UNKNOWN')
 return 'BUNDLE' if r['is_kit'] else 'UNIT'
def validate_codes(codes,expected):
 """Validate exact original API strings; never strip GS separators or crypto tail."""
 from collections import Counter
 if not codes or len(set(codes))!=len(codes):raise ValueError('Empty or duplicate raw codes')
 counted=Counter();cis_seen=set()
 for code in codes:
  raw=code.encode('ascii')
  if not raw.startswith(b'01') or raw[16:18]!=b'21' or not valid_gtin(code[2:16]) or len(raw)<32 or raw[31]!=29:raise ValueError('Not an apparel GS1 code with a 13-character serial')
  cis=code[:31]
  if cis in cis_seen:raise ValueError('Duplicate identification code with different tail')
  cis_seen.add(cis);counted[code[2:16]]+=1
 if dict(counted)!=expected:raise ValueError('GTIN quantities mismatch')
 return {'quantity':len(codes),'unique_cis':len(cis_seen),'by_gtin':dict(counted),'sha256':[hashlib.sha256(c.encode('ascii')).hexdigest() for c in codes]}

TRUE_V4 = TRUE.replace('/v3/', '/v4/')


class NKClient:
    def __init__(self, transport, api_key):
        self.transport, self.api_key = transport, api_key

    def card(self, gtin):
        return self.transport.call('GET', NK, '/v3/feed-product',
                                   params={'apikey': self.api_key, 'format': 'json', 'gtin': gtin})


class SUZClient:
    def __init__(self, transport, token, oms_id):
        self.transport = transport
        self.headers = {'clientToken': token}
        self.oms_id = oms_id

    def status(self, order_id, gtin):
        return self.transport.call('GET', SUZ, '/api/v3/order/status',
                                   params={'omsId': self.oms_id, 'orderId': order_id, 'gtin': gtin},
                                   headers=self.headers)

    def search(self, product_group, start_ms, end_ms, max_pages=20):
        collected = {}
        expected = None
        for page in range(1, max_pages + 1):
            response = self.transport.call(
                'POST', SUZ, '/api/v3/orders/search', params={'omsId': self.oms_id},
                headers=self.headers, body={'filter': {'startCreatedTimestamp': start_ms,
                    'endCreatedTimestamp': end_ms, 'productGroups': [product_group]}, 'limit': 100, 'page': page})
            total, rows = response['totalCount'], response['results']
            if type(total) is not int or total < 0 or not isinstance(rows, list):
                raise ValueError('Unexpected SUZ response')
            if expected is not None and expected != total:
                return {'complete': False, 'results': list(collected.values()), 'reason': 'count_changed'}
            expected = total
            for row in rows:
                order = row['orderId']
                if order in collected:
                    return {'complete': False, 'results': list(collected.values()), 'reason': 'repeated_id'}
                collected[order] = row
            if len(collected) == expected:
                return {'complete': True, 'results': list(collected.values()), 'totalCount': expected}
            if not rows or len(collected) > expected:
                break
        return {'complete': False, 'results': list(collected.values()), 'reason': 'page_limit_or_inconsistent_response'}


class TrueClient:
    def __init__(self, transport, token, inn):
        self.transport, self.inn = transport, inn
        self.headers = {'Authorization': 'Bearer ' + token}

    def codes(self, product_group, cises):
        if not 1 <= len(cises) <= 1000 or len(set(cises)) != len(cises):
            raise ValueError('Supply 1–1000 distinct identification codes')
        return self.transport.call('POST', TRUE, '/cises/info', params={'pg': product_group},
                                   body=cises, headers=self.headers)

    def document(self, product_group, doc_id):
        if not re.fullmatch(r'[A-Za-z0-9_.-]{1,300}', doc_id) or doc_id in ('.', '..'):
            raise ValueError('Invalid document identifier')
        return self.transport.call('GET', TRUE_V4, f'/doc/{doc_id}/info',
                                   params={'pg': product_group, 'body': 'true', 'content': 'true'}, headers=self.headers)

    def documents(self, product_group, direction, date_from, date_to, limit=100, max_pages=10):
        party = {'outgoing': 'senderInn', 'incoming': 'receiverInn'}[direction]
        params = {'pg': product_group, party: self.inn, 'dateFrom': date_from,
                  'dateTo': date_to, 'order': 'ASC', 'limit': limit}
        collected = {}
        cursors = set()
        for page in range(1, max_pages + 1):
            data = self.transport.call('GET', TRUE_V4, '/doc/list', params=params.copy(), headers=self.headers)
            rows = data['results']
            if not isinstance(rows, list) or type(data.get('nextPage')) is not bool:
                raise ValueError('Unexpected GIS MT pagination response')
            for row in rows:
                number = row['number']
                if number in collected:
                    return {'complete': False, 'pages': page, 'results': list(collected.values()), 'reason': 'repeated_id'}
                collected[number] = row
            if not data['nextPage']:
                return {'complete': True, 'pages': page, 'results': list(collected.values())}
            if not rows:
                break
            cursor = rows[-1]['number'], rows[-1]['docDate']
            if cursor in cursors:
                break
            cursors.add(cursor)
            params.update(did=cursor[0], orderedColumnValue=cursor[1], pageDir='NEXT')
        return {'complete': False, 'results': list(collected.values()), 'reason': 'page_limit_or_inconsistent_response'}
