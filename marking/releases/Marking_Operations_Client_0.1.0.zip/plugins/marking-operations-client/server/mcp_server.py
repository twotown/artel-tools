"""Local stdio MCP. Only fixed read operations and local preparation are exposed."""
from datetime import datetime, timezone
import json
import re
from typing import Literal
from uuid import UUID

from mcp.server.fastmcp import FastMCP

from clients import NKClient, SUZClient, TrueClient, Transport, TRUE, card_type, valid_gtin
from demo import DemoTransport, INN, GTIN
from client_profile import Profile, ROOT, restricted_file
from workflow import completion, plan_apparel_remark

mcp = FastMCP('Marking Operations', log_level='ERROR')


def context(service):
    profile = Profile()
    demo = profile.mode == 'demo'
    transport = DemoTransport() if demo else Transport()
    credential = 'demo' if demo else profile.secret(service)
    if service == 'nk':
        return profile, NKClient(transport,credential)
    if service == 'suz':
        oms = '00000000-0000-4000-8000-000000000004' if demo else str(UUID(profile.data['oms_id']))
        return profile, SUZClient(transport,credential,oms)
    return profile, TrueClient(transport,credential,INN if demo else profile.inn)


def scope(profile, result):
    return {'mode':profile.mode,'evidence':'synthetic' if profile.mode=='demo' else 'client_api_response',
            'result':result}


def gtin14(value):
    if not valid_gtin(value):
        raise ValueError('Supply a 13- or 14-digit GTIN with valid checksum')
    return value.zfill(14)


def ci_list(values):
    if not 1<=len(values)<=1000 or len(set(values))!=len(values):
        raise ValueError('Supply 1–1000 unique identification codes')
    if any(not re.fullmatch(r'[!-~]{4,128}',value) for value in values):
        raise ValueError('Use identification codes without the crypto tail or separator characters')
    return values


def one_document(data, correct_id):
    if not isinstance(data,list) or len(data)!=1 or data[0].get('number')!=correct_id:
        raise ValueError('UNKNOWN: document response does not identify a unique matching document')
    return data[0]


@mcp.tool()
def client_status() -> dict:
    """Describe local configuration readiness. This tool makes no requests."""
    profile = Profile()
    credentials = {}
    for service in ('nk','suz','gis'):
        try:
            present = profile.mode=='live_readonly' and bool(profile.secret(service))
        except (ValueError,OSError):
            present = False
        credentials[service] = {'configured':present,'live_connection':'UNKNOWN'}
    return {'mode':profile.mode,'product_groups':profile.groups,'credentials':credentials,
            'live_write_tools':False}


@mcp.tool()
def nk_card(gtin: str) -> dict:
    """Read a National Catalogue card by GTIN. Account and applicability still need verification."""
    profile,client = context('nk')
    gtin = gtin14(gtin)
    data = client.card(gtin[1:] if gtin.startswith('0') else gtin)
    try:
        package = card_type(data,gtin)
    except (ValueError,TypeError):
        package = 'UNKNOWN'
    return scope(profile,{'package_type':package,'card':data})


@mcp.tool()
def suz_order_status(order_id: str, gtin: str) -> dict:
    """Read an existing SUZ order status. Does not retrieve or issue marking codes."""
    profile,client = context('suz')
    return scope(profile,client.status(str(UUID(order_id)),gtin14(gtin)))


@mcp.tool()
def suz_orders(product_group: str, start_ms: int, end_ms: int, max_pages: int = 10) -> dict:
    """Search SUZ orders over explicit epoch-millisecond bounds. Empty does not exclude closed orders."""
    profile,client = context('suz')
    if not 0<start_ms<=end_ms or not 1<=max_pages<=20:
        raise ValueError('Invalid time bounds or page cap')
    return scope(profile,client.search(profile.product_group(product_group),start_ms,end_ms,max_pages))


@mcp.tool()
def gis_documents(product_group: str, direction: Literal['incoming','outgoing'],
                  date_from: str, date_to: str, max_pages: int = 10) -> dict:
    """Read the scoped participant's GIS MT document list with pagination evidence."""
    profile,client = context('gis')
    start,end = [datetime.fromisoformat(date.replace('Z','+00:00')) for date in (date_from,date_to)]
    if not all(d.tzinfo for d in (start,end)) or start>end or not 1<=max_pages<=20:
        raise ValueError('Use timezone-aware ordered dates and a page cap of 1–20')
    utc_dates = [d.astimezone(timezone.utc).isoformat(timespec='milliseconds').replace('+00:00','Z') for d in (start,end)]
    return scope(profile,client.documents(profile.product_group(product_group),direction,*utc_dates,max_pages=max_pages))


@mcp.tool()
def gis_document(product_group: str, document_id: str) -> dict:
    """Read one existing GIS MT document. This operation does not submit any document."""
    profile,client = context('gis')
    return scope(profile,one_document(client.document(profile.product_group(product_group),document_id),document_id))


@mcp.tool()
def gis_code_status(product_group: str, identification_codes: list[str]) -> dict:
    """Read code status. Uses the documented read-only POST cises/info."""
    profile,client = context('gis')
    response = client.codes(profile.product_group(product_group),ci_list(identification_codes))
    return scope(profile,response)


@mcp.tool()
def gis_check_completion(product_group: str, document_id: str, identification_codes: list[str]) -> dict:
    """Check accepted document, its exact code set, and each code's final owner and status."""
    profile,client = context('gis')
    group = profile.product_group(product_group)
    expected = ci_list(identification_codes)
    document = one_document(client.document(group,document_id),document_id)
    rows = client.transport.call('GET',TRUE,'/doc/cises',
              params={'documentId':document_id,'productGroup':group},headers=client.headers)
    if not isinstance(rows,dict) or not isinstance(rows.get('products'),list):
        raise ValueError('UNKNOWN: document code response is outside the verified shape')
    codes = [row['cis'] for row in rows['products']]
    return scope(profile,completion(document,document_id,codes,client.codes(group,expected),expected,client.inn))


@mcp.tool()
def prepare_remark_draft(operation_date: str, products: list[dict[str, str]],
                         reason: str, applied_confirmed: bool) -> dict:
    """Prepare a local unsigned apparel KM_SPOILED candidate. Call only after checking applicability and explicit physical application."""
    profile = Profile()
    profile.product_group('lp')
    return scope(profile,plan_apparel_remark(INN if profile.mode=='demo' else profile.inn,
                                           operation_date,products,reason,applied_confirmed))


def workspace(profile):
    return restricted_file(profile.root,profile.data.get('operator_workspace','workspace'))


def simple_filename(value, extension):
    if not re.fullmatch(r'[a-zA-Z0-9_-]{1,80}',value):
        raise ValueError('Use a simple file identifier of letters, digits, underscores or hyphens')
    return value+extension


@mcp.tool()
def label_demo(output_name: str = 'demo-label') -> dict:
    """Generate a watermarked non-retail demo PDF and verify both barcodes locally."""
    import pymupdf as fitz
    from demo import CIS
    from gs1 import source_page
    from labels import build_pdf
    profile=Profile()
    output=restricted_file(workspace(profile),simple_filename(output_name,'.pdf'))
    output.parent.mkdir(parents=True,exist_ok=True)
    template=json.loads((ROOT/'templates/label.example.json').read_text())
    item={'title':'Demo garment','sku':'DEMO-01','gtin':GTIN,'linear_format':'EAN13','linear_code':GTIN[1:]}
    with fitz.open(stream=source_page(CIS.encode('ascii'),demo=True),filetype='pdf') as src:
        report=build_pdf(src,item,template,output,1,demo=True)
    return {'mode':'demo','result':report,'local_file':str(output)}


@mcp.tool()
def build_client_labels(sku: str, input_name: str, output_name: str, quantity: int,
                        source_kind: Literal['official_pdf','suz_response']) -> dict:
    """Build and verify a SKU PDF from an original file already in the configured client workspace."""
    import pymupdf as fitz
    from labels import build_pdf,build_from_codes
    profile=Profile()
    if profile.mode!='live_readonly':
        raise ValueError('Use label_demo until the client profile is configured')
    item=profile.catalog_item(sku)
    template=json.loads(restricted_file(profile.root,profile.data['label_template']).read_text(encoding='utf-8'))
    font=restricted_file(profile.root,profile.data['font_file']) if profile.data.get('font_file') else None
    ws=workspace(profile)
    output=restricted_file(ws,simple_filename(output_name,'.pdf'))
    src=restricted_file(ws,simple_filename(input_name,'.pdf' if source_kind=='official_pdf' else '.json'))
    if output.exists():
        raise FileExistsError('Output already exists')
    if source_kind=='official_pdf':
        with fitz.open(src) as source:
            report=build_pdf(source,item,template,output,quantity,font_file=font)
    else:
        if item['product_group']!='lp':
            raise ValueError('API-string encoder currently supports only the verified apparel format')
        response=json.loads(src.read_text(encoding='utf-8'))
        if not response.get('blockId') or not response.get('omsId') or response['omsId']!=profile.data['oms_id']:
            raise ValueError('Original response provenance is missing or belongs to another OMS')
        report=build_from_codes(response['codes'],item,template,output,quantity,font_file=font)
    return scope(profile,{**report,'local_file':str(output)})


if __name__=='__main__':
    mcp.run(transport='stdio')
