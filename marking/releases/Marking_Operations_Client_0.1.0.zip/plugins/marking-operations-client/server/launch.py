"""Start the installed local runtime without provisioning or reading secrets."""
import os
import sys
from pathlib import Path

root = Path(os.environ.get('MARKING_CLIENT_HOME', Path.home() / '.local/share/marking-operations-client')).expanduser()
python = root / 'venv' / ('Scripts/python.exe' if os.name == 'nt' else 'bin/python')
if not python.is_file():
    raise SystemExit('Marking Operations: run setup.py from the installer before opening a local chat.')
script = Path(__file__).resolve().with_name('mcp_server.py')
os.execv(str(python), [str(python), '-E', '-s', '-B', str(script)])
