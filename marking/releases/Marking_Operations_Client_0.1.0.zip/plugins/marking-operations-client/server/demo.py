"""Synthetic documents, no network. Identifiers are sample-only."""
from clients import NK, SUZ, TRUE, TRUE_V4

GTIN = '00000000000017'
CIS = '01' + GTIN + '21DEMO000000001'
ORDER = '00000000-0000-4000-8000-000000000001'
DOCUMENT = '00000000-0000-4000-8000-000000000002'
OTHER_DOC = '00000000-0000-4000-8000-000000000003'
INN = '000000000000'


class DemoTransport:
    def call(self, method, base, path, params=None, body=None, headers=None):
        params = params or {}
        route = (method, base, path)
        if route == ('GET', NK, '/v3/feed-product'):
            if params['gtin'].zfill(14) != GTIN:
                return {'result': []}
            return {'result': [{'identified_by':[{'value':GTIN}], 'good_status':'published',
                                'good_mark_flag':True, 'is_kit':False, 'good_name':'Demo garment'}]}
        if route == ('GET', SUZ, '/api/v3/order/status'):
            return [{'gtin':GTIN,'status':'ACTIVE','leftInBuffer':0}] if params['orderId']==ORDER and params['gtin']==GTIN else []
        if route == ('POST', SUZ, '/api/v3/orders/search'):
            return {'totalCount':1,'results':[{'orderId':ORDER}]} if body['page']==1 else {'totalCount':1,'results':[]}
        if route == ('GET', TRUE_V4, '/doc/list'):
            if params.get('receiverInn'):
                return {'nextPage':False,'results':[]}
            if params.get('pageDir')=='NEXT':
                assert params['did']==OTHER_DOC
                return {'nextPage':False,'results':[self.doc()]}
            return {'nextPage':True,'results':[{'number':OTHER_DOC,'type':'LK_REMARK',
                     'docDate':'2025-01-01T00:00:00.000Z','status':'CHECKED_NOT_OK','senderInn':INN}]}
        if route == ('GET', TRUE_V4, f'/doc/{DOCUMENT}/info'):
            return [self.doc()]
        if route == ('POST', TRUE, '/cises/info'):
            return [{'cisInfo':{'cis':c,'ownerInn':INN,'status':'INTRODUCED'}}
                    for c in body if c==CIS]
        if route == ('GET', TRUE, '/doc/cises'):
            return {'products':[{'cis':CIS}]}
        raise ValueError('Route unavailable in demo mode')

    @staticmethod
    def doc():
        return {'number':DOCUMENT,'docDate':'2025-01-02T00:00:00.000Z',
                'type':'LK_REMARK','status':'CHECKED_OK','senderInn':INN,'errors':[]}
