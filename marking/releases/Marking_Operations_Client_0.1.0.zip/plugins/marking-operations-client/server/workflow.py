from collections import Counter
from datetime import date
import re
from uuid import UUID

from clients import digest, valid_gtin


def plan_apparel_remark(inn, operation_date, products, reason, applied_confirmed):
    """Prepare an unsigned draft locally from explicit, already approved facts."""
    if not applied_confirmed:
        raise ValueError('Physical application has not been confirmed')
    if reason != 'KM_SPOILED':
        raise ValueError('This draft adapter only covers confirmed KM_SPOILED apparel cases')
    date.fromisoformat(operation_date)
    if not 1 <= len(products) <= 1000:
        raise ValueError('Supply 1–1000 products')
    cleaned = []
    for p in products:
        if set(p) - {'new_uin','last_uin','tnved_10','package_type'}:
            raise ValueError('Unrecognized field in the draft')
        if p.get('package_type') not in ('UNIT','BUNDLE'):
            raise ValueError('Verify the applicable package type')
        code = p['new_uin']
        if not re.fullmatch(r'01[0-9]{14}21[!-~]{13}', code) or not valid_gtin(code[2:16]):
            raise ValueError('Invalid identification code')
        item = {'new_uin':code}
        if p.get('last_uin'):
            if not re.fullmatch(r'01[0-9]{14}21[!-~]{13}', p['last_uin']) or not valid_gtin(p['last_uin'][2:16]) or p['last_uin'] == code:
                raise ValueError('Invalid previous identification code')
            item['last_uin'] = p['last_uin']
        if p.get('tnved_10'):
            if not re.fullmatch(r'[0-9]{10}',p['tnved_10']):
                raise ValueError('Invalid TN VED')
            item['tnved_10'] = p['tnved_10']
        if 'last_uin' not in item and 'tnved_10' not in item:
            raise ValueError('Actual TN VED required when an applicable scenario allows omitting the previous code')
        cleaned.append(item)
    if len({x['new_uin'] for x in cleaned}) != len(cleaned):
        raise ValueError('Duplicate codes in draft')
    body = {'participant_inn':inn,'remarking_date':operation_date,'remarking_cause':reason,'products':cleaned}
    return {'state':'UNSIGNED_DRAFT','sha256':digest(body),'payload':body}


def completion(document, document_id, document_codes, statuses, expected, inn):
    target = set(expected)
    infos = [r.get('cisInfo', {}) for r in statuses]
    counts = Counter(r.get('status', 'UNKNOWN') for r in infos)
    status_codes = Counter(r.get('cis') for r in infos)
    complete = (
        document.get('number') == document_id and document.get('status') == 'CHECKED_OK'
        and not document.get('errors') and not document.get('commonErrors')
        and bool(target) and len(expected) == len(target)
        and Counter(document_codes) == Counter(expected)
        and status_codes == Counter(expected)
        and all(r.get('status') == 'INTRODUCED' and r.get('ownerInn') == inn for r in infos)
    )
    return {'complete':complete,'document_status':document.get('status','UNKNOWN'),
            'expected':len(expected),'statuses':dict(counts),'readback_count':len(infos)}


def accepted_document_id(http_status, response_bytes):
    """Interpret response only after durable raw capture. Failure is UNKNOWN, never a retry decision."""
    if http_status not in {200, 201}:
        raise ValueError('UNKNOWN: reconcile document before any further submission')
    raw = response_bytes.decode('utf-8').strip()
    if raw.startswith('"'):
        import json
        raw = json.loads(raw)
    try:
        return str(UUID(raw))
    except (ValueError, TypeError, AttributeError):
        raise ValueError('UNKNOWN: accepted response has no recognized document identifier') from None
